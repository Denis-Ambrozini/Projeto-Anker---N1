﻿namespace ProjetoAnkerN1.Controllers
{
    public class AlunoController
    {
        public void ConsultarAluno()
        {
            Console.WriteLine("Consultando alunos...");
            string[] consultandoAlunos = File.ReadAllLines("alunos.dat");
            foreach(string aluno in consultandoAlunos)
            {
                string[] dadosAluno = aluno.Split(';');
                Console.WriteLine(dadosAluno);
            }
        }
    }
}
